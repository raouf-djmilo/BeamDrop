window.BEAMDROP_BUILD = {
  version: "1.6.2",
  buildHash: "git-6abd28e3",
  buildTimestamp: 1790781667,
  patchNotes: "Live WebRTC DataChannel optimizations & instant two-way handshake"
};

window.BEAMDROP_BUILD = {
  version: "1.6.2",
  buildHash: "git-6abd0303",
  buildTimestamp: 1790771971,
  patchNotes: "Live WebRTC DataChannel optimizations & instant two-way handshake"
};

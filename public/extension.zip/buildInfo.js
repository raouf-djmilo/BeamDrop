window.BEAMDROP_BUILD = {
  version: "1.6.2",
  buildHash: "git-6abd17fb",
  buildTimestamp: 1790777339,
  patchNotes: "Live WebRTC DataChannel optimizations & instant two-way handshake"
};

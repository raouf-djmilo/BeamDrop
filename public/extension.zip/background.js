/**
 * BeamDrop Background Service Worker (Manifest V3)
 * Handles context menus, OTA background update checks, toolbar notification badges, and direct downloads.
 */

const DEFAULT_VERCEL_URL = "https://beam-drop-mu.vercel.app";
const GITHUB_RAW_URL = "https://raw.githubusercontent.com/raouf-djmilo/BeamDrop/main/public/version.json";
const UPDATE_ALARM_NAME = "beamdrop_periodic_update_check";

// Initialize on installed
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "beamdrop_send_selection",
    title: "BeamDrop: Send selection to Phone",
    contexts: ["selection"]
  });

  chrome.contextMenus.create({
    id: "beamdrop_send_link",
    title: "BeamDrop: Send link to Phone",
    contexts: ["link"]
  });

  chrome.contextMenus.create({
    id: "beamdrop_send_image",
    title: "BeamDrop: Send image URL to Phone",
    contexts: ["image"]
  });

  chrome.contextMenus.create({
    id: "beamdrop_open_sidepanel",
    title: "BeamDrop: Open in Side Panel (Persistent)",
    contexts: ["action"]
  });

  // Setup periodic background check for updates (every 30 mins, with immediate 1-min initial check)
  chrome.alarms.create(UPDATE_ALARM_NAME, {
    periodInMinutes: 30,
    delayInMinutes: 1
  });

  // Check immediately on install
  checkCloudForUpdates();
});

// Periodic alarm listener
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === UPDATE_ALARM_NAME) {
    checkCloudForUpdates();
  }
});

// Notification click listener
if (chrome.notifications && chrome.notifications.onClicked) {
  chrome.notifications.onClicked.addListener((notificationId) => {
    if (notificationId.startsWith('beamdrop_update_')) {
      chrome.action.openPopup ? chrome.action.openPopup() : null;
    }
  });
}

// Context Menu actions
chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === "beamdrop_open_sidepanel") {
    if (chrome.sidePanel && chrome.sidePanel.open) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0] && tabs[0].id) {
          chrome.sidePanel.open({ tabId: tabs[0].id }).catch(() => {});
        }
      });
    }
    return;
  }

  let contentToSend = "";
  if (info.menuItemId === "beamdrop_send_selection" && info.selectionText) {
    contentToSend = info.selectionText;
  } else if (info.menuItemId === "beamdrop_send_link" && info.linkUrl) {
    contentToSend = info.linkUrl;
  } else if (info.menuItemId === "beamdrop_send_image" && info.srcUrl) {
    contentToSend = info.srcUrl;
  }

  if (contentToSend && chrome.storage) {
    chrome.storage.local.set({ pendingShareText: contentToSend }, () => {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icons/icon48.png",
        title: "BeamDrop Ready",
        message: "Text ready to beam! Click BeamDrop in your toolbar to generate your QR portal."
      });
    });
  }
});

// Background update available listener (Web Store / CRX auto-update)
chrome.runtime.onUpdateAvailable.addListener((details) => {
  console.log('Native update downloaded and waiting to install:', details.version);
  chrome.action.setBadgeText({ text: 'NEW' });
  chrome.action.setBadgeBackgroundColor({ color: '#06b6d4' });
  if (chrome.storage && chrome.storage.local) {
    chrome.storage.local.set({
      nativeUpdateReady: true,
      latestVersion: details.version
    });
  }
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'check_updates_now') {
    checkCloudForUpdates().then((res) => sendResponse(res));
    return true;
  }
  if (message.action === 'clear_update_badge') {
    chrome.action.setBadgeText({ text: '' });
    sendResponse({ cleared: true });
    return true;
  }
  if (message.action === 'trigger_runtime_reload') {
    setTimeout(() => {
      if (chrome.runtime.reload) {
        chrome.runtime.reload();
      }
    }, 100);
    sendResponse({ reloading: true });
    return true;
  }
  if (message.action === 'download_update_package') {
    const url = message.url || `${DEFAULT_VERCEL_URL}/extension.zip`;
    const filename = message.filename || 'BeamDrop-Extension-Latest.zip';
    if (chrome.downloads && chrome.downloads.download) {
      chrome.downloads.download({
        url: url,
        filename: filename,
        saveAs: false,
        conflictAction: 'overwrite'
      }, (downloadId) => {
        sendResponse({ success: Boolean(downloadId), downloadId });
      });
      return true;
    } else {
      sendResponse({ success: false, reason: 'downloads API unavailable' });
      return true;
    }
  }
  if (message.action === 'request_store_update_check') {
    if (chrome.runtime.requestUpdateCheck) {
      chrome.runtime.requestUpdateCheck((status, details) => {
        sendResponse({ status, details });
      });
      return true;
    } else {
      sendResponse({ status: 'unsupported' });
      return true;
    }
  }
});

// Background Cloud Updater Check (Vercel + GitHub Raw Dual Polling)
async function checkCloudForUpdates() {
  try {
    let installedVer = (chrome.runtime && chrome.runtime.getManifest)
      ? (chrome.runtime.getManifest().version || '1.3.0')
      : '1.3.0';

    // Support test simulation version override if set in storage
    if (chrome.storage && chrome.storage.local) {
      const storedSim = await chrome.storage.local.get(['simulated_installed_version', 'custom_update_server']);
      if (storedSim && storedSim.simulated_installed_version) {
        installedVer = storedSim.simulated_installed_version;
      }
    }

    let targetBaseUrl = DEFAULT_VERCEL_URL;
    if (chrome.storage && chrome.storage.local) {
      const stored = await chrome.storage.local.get(['custom_update_server']);
      if (stored && stored.custom_update_server) {
        targetBaseUrl = stored.custom_update_server.replace(/\/$/, '');
      }
    }

    const endpoints = [
      `${targetBaseUrl}/version.json?_t=${Date.now()}`,
      `${GITHUB_RAW_URL}?_t=${Date.now()}`
    ];

    let data = null;
    for (const url of endpoints) {
      try {
        const resp = await fetch(url, { cache: 'no-store' });
        if (resp.ok) {
          data = await resp.json();
          if (data && data.version) break;
        }
      } catch (e) {
        console.debug('Failed fetching from:', url, e);
      }
    }

    if (!data || !data.version) return { hasUpdate: false };

    const remoteVer = data.version;
    const isNewer = compareSemver(remoteVer, installedVer) > 0;

    if (isNewer) {
      // Set badge on toolbar icon
      chrome.action.setBadgeText({ text: 'NEW' });
      chrome.action.setBadgeBackgroundColor({ color: '#06b6d4' }); // Glowing cyan
      chrome.action.setTitle({ title: `BeamDrop Update Available (v${remoteVer})! Click to update.` });

      if (chrome.storage && chrome.storage.local) {
        await chrome.storage.local.set({
          updateAvailable: true,
          latestVersion: remoteVer,
          updateDownloadUrl: data.downloadUrl || `${targetBaseUrl}/extension.zip`,
          updateHighlights: data.highlights || [],
          updateChangelog: data.changelog || [],
          lastCheckedTimestamp: Date.now()
        });
      }

      // Native OS notification (alert user even when popup is closed)
      if (chrome.notifications && chrome.notifications.create) {
        chrome.notifications.create(`beamdrop_update_${remoteVer}`, {
          type: "basic",
          iconUrl: "icons/icon48.png",
          title: `⚡ BeamDrop Update v${remoteVer} Available!`,
          message: `A new version of BeamDrop was published on GitHub/Vercel. Click toolbar icon to download and update.`
        });
      }

      return { hasUpdate: true, version: remoteVer, data };
    } else {
      chrome.action.setBadgeText({ text: '' });
      return { hasUpdate: false, version: remoteVer, data };
    }
  } catch (err) {
    console.debug('Background update check skipped/failed:', err);
    return { hasUpdate: false };
  }
}

function compareSemver(v1, v2) {
  const p1 = (v1 || '0.0.0').replace(/^v/, '').split('.').map(n => parseInt(n, 10) || 0);
  const p2 = (v2 || '0.0.0').replace(/^v/, '').split('.').map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(p1.length, p2.length); i++) {
    const num1 = p1[i] || 0;
    const num2 = p2[i] || 0;
    if (num1 > num2) return 1;
    if (num1 < num2) return -1;
  }
  return 0;
}
